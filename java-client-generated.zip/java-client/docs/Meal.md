
# Meal

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mealId** | **Long** |  |  [optional]
**mealName** | **String** |  |  [optional]
**recipes** | [**List&lt;Recipe&gt;**](Recipe.md) |  |  [optional]



