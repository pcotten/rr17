
# MealPlan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mealPlanId** | **Long** |  |  [optional]
**name** | **String** |  |  [optional]
**meals** | [**List&lt;Meal&gt;**](Meal.md) |  |  [optional]



