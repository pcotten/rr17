
# Instruction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**instructionOrderIndex** | **Long** |  |  [optional]
**instructionText** | **String** |  |  [optional]



