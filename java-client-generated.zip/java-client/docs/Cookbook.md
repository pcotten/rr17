
# Cookbook

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **Long** |  |  [optional]
**recipeId** | **List&lt;Long&gt;** |  |  [optional]



